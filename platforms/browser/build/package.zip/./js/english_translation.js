var English = {
    'Snooker Counter': 'Snooker Counter',
    'Nowa gra': 'New game',
    'Historia': 'History',
    'Historia twoich gier': 'History of your games',
    'Czy na pewno chcesz usunąć ten rezultat?': 'Do you really want to delete this record?',
    'OK': 'OK',
    'Anuluj': 'Cancel',
    'Start': 'Start',
    'Faul': 'Foul',
    'Zakoncz': 'Finish',
    'Zakończyć grę?': 'Finish the game?',
    'Edytuj wynik': 'Edit score',
    '+4pkt': '+4pts',
    '+5pkt': '+5pts',
    '+6pkt': '+6pts',
    '+7pkt': '+7pts'
}